export type TranslatableMessages = {
  [key: string]: string;
};
