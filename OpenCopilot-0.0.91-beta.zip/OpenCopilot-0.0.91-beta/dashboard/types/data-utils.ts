export type WithPagination<T> = {
    data: T;
    total_pages: number;
} 