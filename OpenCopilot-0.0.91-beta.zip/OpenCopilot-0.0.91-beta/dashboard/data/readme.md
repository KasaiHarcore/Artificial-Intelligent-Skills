# Data

This directory holds everything related to data fetching for the entire application.
