import { FlowRenderer } from '@/components/domain/new-flows-editor/Renderer'
import React from 'react'


export default function WorkflowPage() {
    return (
        <FlowRenderer />
    )
}
