import React from "react";
import { KnowledgeTable } from "./_parts/KnowledgeTable";

export default function KnowledgePage() {
  return <KnowledgeTable />;
}
