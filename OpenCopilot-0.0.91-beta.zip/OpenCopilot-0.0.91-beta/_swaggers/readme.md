# Example swagger files:

- You can use these files to play around with your copilots.
- Each swagger file here is already cleaned and optimized to be ingested by the LLM.
- Feel free to contribute your swagger files here.
