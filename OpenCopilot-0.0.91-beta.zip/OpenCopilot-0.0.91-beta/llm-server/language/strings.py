languages = {
    "en": {
        "checking_if_actionable": "Checking if actionable ... \n",
        "information_query_found": "Informational query found...",
        "checking_bias": "Validating the request \n",
        "sorry_i_cannot_help": "Sorry, I cannot help with that. \n",
    },
    "ar": {
        "checking_if_actionable": "التحقق اذا كانت العملية تتطلب تواصل خارجي ... \n",
        "information_query_found": "تحصيل المعلومات  ...",
        "checking_bias": "انا اتحقق من الطلب ... \n",
        "sorry_i_cannot_help": "عذراً، لا أستطيع المساعدة في ذلك. \n",
    },
}
