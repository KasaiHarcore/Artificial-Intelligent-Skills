- Make sure all action APIs are ok (payload wise, DTO, code)
- Loop on all swagger files we have, then convert the endpoints into actions
- Index all actions into Qdrant
- When the user ask questions, lookup in the actions namespace


----

- We will not have swagger files loaded when the user ask questions
- We will all of our users actions inside the db (GET actions)

----


- Flows.



