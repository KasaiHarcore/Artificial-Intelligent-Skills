flow_generation_prompts = ""

api_generation_prompt = "Use encoded value for channel. When sending message, also identify whether the message is being sent to a channel or a user and generate body accordingly."
